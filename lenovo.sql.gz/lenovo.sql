-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018 �?07 �?09 �?16:57
-- 服务器版本: 5.5.54-log
-- PHP 版本: 5.6.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `lenovo`
--

-- --------------------------------------------------------

--
-- 表的结构 `addr`
--

CREATE TABLE IF NOT EXISTS `addr` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `sname` varchar(255) DEFAULT NULL,
  `stel` varchar(255) DEFAULT NULL,
  `addr` varchar(255) DEFAULT NULL,
  `addrInfo` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `addr`
--

INSERT INTO `addr` (`id`, `uid`, `sname`, `stel`, `addr`, `addrInfo`, `email`) VALUES
(1, 1, '张三', '13122548756', '上海市普陀区', '真北路1628弄8号楼五楼', '3428654200@qq.com'),
(2, 3, '李四', '1817276212', '上海市普陀区', '长征镇丽和苑1928弄', '878121212@qq.com');

-- --------------------------------------------------------

--
-- 表的结构 `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(20) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL COMMENT '密码',
  `time` int(11) DEFAULT NULL,
  `lasttime` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=45 ;

--
-- 转存表中的数据 `admin`
--

INSERT INTO `admin` (`id`, `name`, `pass`, `time`, `lasttime`, `count`, `status`) VALUES
(39, '张三', 'eyJpdiI6IkhoWVVHRXp3cW9Sd2VwU0VzSjNhQlE9PSIsInZhbHVlIjoicWl4Qm1sUE42cFJNaTlRSWpNc2haQT09IiwibWFjIjoiMzg4M2Y2YmM4MTFlZjhmNjg0MzcxMWZmMzU3OTJlNWViMmQ1YjVjNjFlMWI2MDI0NGYxMGM1MmI1MWM1ZGE4ZSJ9', 1530778189, NULL, NULL, 0),
(40, 'admin', 'eyJpdiI6Ik40M0tDWTVLTDFGYU9CWXBFMTJDMnc9PSIsInZhbHVlIjoiU1ZUeVFGdzhTdWFsQVg5b0diM1wvZWc9PSIsIm1hYyI6IjIxNjYxNTY0YzE3NjhhOGFmOTM5MzQyMjY0ZDAxMDk5M2E5ZDUyODE2YjQxMjgyYmE3YzlmNWFlYjk3OTY0MzYifQ==', 1530778209, NULL, NULL, 0),
(41, 'zhangsan', 'eyJpdiI6ImJkV0hsWVBpM2w0eTc1RGVJNGZPcFE9PSIsInZhbHVlIjoiUDd0RWJjUG96WHZ2TWRZWFJOaVF0Zz09IiwibWFjIjoiMDc5MDYzMzMwYThlOGJiZDk1NTYzMTBmYmU1ZGY4YTY4MWZlNDU2ZmZmZTExMDc5YmQ0ZDgwYjZmZGNhOTg0NiJ9', 1530778223, NULL, NULL, 0),
(42, 'lishi', 'eyJpdiI6IkYwbVNsOVpxcytEekpmdDJtb1hxTWc9PSIsInZhbHVlIjoiUzBmaGplNXNGT2IrSW9vTkRkc3lpdz09IiwibWFjIjoiMjg0YjM1YzI0ODViNTNiOTBiZTVmZTJiMjZiMTA4NDRjOGRkYzQ3ZTU4MDMzNTEwOWZjN2ZiODM4ODRmMGU4YSJ9', 1530779486, NULL, NULL, 1),
(43, 'wangwu', 'eyJpdiI6IlNXSXNDWG40Z01hUHpzOFhPOGVjVlE9PSIsInZhbHVlIjoiSjBNSFdQMmpoTTg4OVNMd3ZKTklwdz09IiwibWFjIjoiYjI4MmMzMTcyMDZhN2UxNWFkYWVjMWMwMWJhNmQ4ZjQ3Nzc4MWU0YmU1MmE5YWIzMjI2NmJhNWExNTZmNjNmYSJ9', 1530779636, NULL, NULL, 1),
(44, 'zhaoliu', 'eyJpdiI6ImFWendyQW03R1hhamkzK1ByVUNUVVE9PSIsInZhbHVlIjoiWlwvNGN1OGl5Y1VRV0FLRzRDODFYZHc9PSIsIm1hYyI6IjM4OWJlNTM2NzhmYTZjYzgxNzkxMDU1MTIxN2Y5NjE1ZWFiYzQ0YTM5ODU4NjgxY2RlMDYwYmY5NWRjMTQxNjcifQ==', 1530779647, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- 表的结构 `ads`
--

CREATE TABLE IF NOT EXISTS `ads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `img` varchar(255) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `href` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `ads`
--

INSERT INTO `ads` (`id`, `img`, `sort`, `href`, `title`) VALUES
(1, '1530945342210309522.jpg', 12, 'http://www.mobanw.com', '企业法律顾问+律师上门'),
(2, '15309454671058797151.jpg', 14, 'http://www.baidu.com', '第二届皮肤病治疗成果展暨患者援助活动');

-- --------------------------------------------------------

--
-- 表的结构 `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `start` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `statu` tinyint(4) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `comment`
--

INSERT INTO `comment` (`id`, `uid`, `gid`, `text`, `start`, `time`, `statu`, `img`) VALUES
(1, 1, 4, '这是评论商品一内容', 3, 191872643, 0, NULL),
(2, 1, 5, '这是评论商品二内容', 4, 121872643, 1, NULL),
(3, 3, 6, '这是评论商品一内容', 5, 194372643, 2, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `goods`
--

CREATE TABLE IF NOT EXISTS `goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  `text` text,
  `config` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `goods`
--

INSERT INTO `goods` (`id`, `cid`, `title`, `info`, `img`, `price`, `num`, `text`, `config`) VALUES
(4, 9, '西服', '西服西服西服西服西服西服西服', '1530943162183717767.gif', 812.2, 4211, '<p style="text-align: center;"><strong>是高了公司了零售肯德玛纳</strong></p><p style="text-align: center;"><strong><img src="/ueditor/php/upload/image/20180707/1530943216.gif" title="1530943216.gif" alt="swt_center.gif"/></strong></p><p></p>', '<p>宿舍了哥老关色卡色</p>'),
(5, 10, '多彩裙子', '多彩裙子多彩裙子多彩裙子多彩裙子', '15309434451489882937.jpg', 731.32, 1928, '<p>少时诵诗书所所所所个额各色</p><p style="text-align: center;"><img src="/ueditor/php/upload/image/20180707/1530943475.jpg" title="1530943475.jpg" alt="4_3.jpg"/></p>', '<p>是是是水水水水色哥额</p>'),
(6, 11, '领带', '领带领带领带', '15309497121156697030.jpg', 127, 4122, '<p>是是哥哥色</p>', '<p>个色色</p>');

-- --------------------------------------------------------

--
-- 表的结构 `goodsimg`
--

CREATE TABLE IF NOT EXISTS `goodsimg` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gid` int(11) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- 转存表中的数据 `goodsimg`
--

INSERT INTO `goodsimg` (`id`, `gid`, `img`) VALUES
(1, 4, '15309431681867077487.gif'),
(2, 4, '15309431691252876708.gif'),
(3, 4, '15309431702084700439.gif'),
(4, 4, '15309431712001012430.gif'),
(5, 4, '1530943172831950392.gif'),
(6, 5, '15309434541577521186.jpg'),
(7, 5, '1530943454590459573.png'),
(8, 5, '1530943454849618010.png'),
(9, 5, '15309434541586939218.png'),
(10, 5, '1530943455755899287.png'),
(11, 6, '15309497351891748272.png'),
(12, 6, '15309497351385072859.jpg'),
(13, 6, '15309497351590731628.jpg'),
(14, 6, '1530949735454739995.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `money` tinyint(4) DEFAULT NULL,
  `sid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `orders`
--

INSERT INTO `orders` (`id`, `code`, `uid`, `gid`, `price`, `num`, `aid`, `time`, `money`, `sid`) VALUES
(1, '00001', 1, 4, 200, 2, 1, 192191872, 0, 6),
(2, '1100', 3, 5, 400, 1, 2, 2652373, 1, 2),
(3, '1100', 3, 6, 100, 3, 2, 982762423, 1, 3);

-- --------------------------------------------------------

--
-- 表的结构 `orderstatu`
--

CREATE TABLE IF NOT EXISTS `orderstatu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `orderstatu`
--

INSERT INTO `orderstatu` (`id`, `name`) VALUES
(1, '未付款'),
(2, '已发货'),
(3, '在途中'),
(4, '配送中s'),
(5, '签收'),
(6, '已完成');

-- --------------------------------------------------------

--
-- 表的结构 `slider`
--

CREATE TABLE IF NOT EXISTS `slider` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `img` varchar(255) DEFAULT NULL,
  `order` tinyint(4) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `href` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `slider`
--

INSERT INTO `slider` (`id`, `img`, `order`, `title`, `href`) VALUES
(1, '1530928643322473508.gif', 12, '滚动图片', 'baidu.com'),
(2, '153092880980050712.gif', 12, '滚动图2', 'baidu.com');

-- --------------------------------------------------------

--
-- 表的结构 `types`
--

CREATE TABLE IF NOT EXISTS `types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `is_lou` tinyint(4) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- 转存表中的数据 `types`
--

INSERT INTO `types` (`id`, `name`, `pid`, `path`, `sort`, `is_lou`, `title`, `keywords`, `description`) VALUES
(1, '衣服', 0, '0,', 2, 0, '衣服', '衣服', '衣服'),
(2, '一级分类', 0, '0,', 1, 1, '一级分类', '一级分类', '一级分类'),
(5, '男装', 1, '0,1,', 11, 1, '男装', '男装男装', '男装男装男装男装'),
(6, '女装', 1, '0,1,', 13, 1, '女装', '女装女装', '女装女装女装女装女装'),
(9, '西服', 5, '0,1,5,', 14, 0, '西服', '西服西服', '西服西服西服西服西服'),
(10, '裙子', 6, '0,1,6,', 17, 1, '裙子裙子', '裙子裙子裙子', '裙子裙子裙子裙子裙子'),
(11, '领带', 5, '0,1,5,', 16, 0, '领带', '领带领带', '领带领带领带');

-- --------------------------------------------------------

--
-- 表的结构 `typesads`
--

CREATE TABLE IF NOT EXISTS `typesads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(11) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `typesads`
--

INSERT INTO `typesads` (`id`, `cid`, `img`, `type`, `title`) VALUES
(1, 2, '1530946607651836419.jpg', 0, '企业法律顾问+律师上门'),
(2, 1, '15309467701271500597.jpg', 1, '京、沪三甲专家团联合会诊行动');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `email` varchar(20) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `tel` varchar(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `token` varchar(50) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `pass`, `tel`, `status`, `time`, `token`, `aid`) VALUES
(1, 'user1', '3428654200@qq.com', 'dlai23232323', '13122457845', 0, 131224578, '13122457845', 0),
(2, 'user2', '1158644857@qq.com', '1281872uik123', '18544587521', 1, 185445875, '18544587521', 1),
(3, 'user3', '136557852@qq.com', '1281872uik123', '18544587521', 2, 135445875, '13131344343553', 2);

-- --------------------------------------------------------

--
-- 表的结构 `userinfo`
--

CREATE TABLE IF NOT EXISTS `userinfo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `sex` tinyint(4) DEFAULT NULL,
  `birthday` int(11) DEFAULT NULL,
  `addr` varchar(255) DEFAULT NULL,
  `addrInfo` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

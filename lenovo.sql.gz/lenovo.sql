-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018 �?07 �?13 �?17:15
-- 服务器版本: 5.5.54-log
-- PHP 版本: 5.6.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `lenovo`
--

-- --------------------------------------------------------

--
-- 表的结构 `addr`
--

CREATE TABLE IF NOT EXISTS `addr` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `sname` varchar(255) DEFAULT NULL,
  `stel` varchar(255) DEFAULT NULL,
  `addr` varchar(255) DEFAULT NULL,
  `addrInfo` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `addr`
--

INSERT INTO `addr` (`id`, `uid`, `sname`, `stel`, `addr`, `addrInfo`, `email`) VALUES
(1, 1, '张三', '13122548756', '上海市普陀区', '真北路1628弄8号楼五楼', '3428654200@qq.com'),
(2, 3, '李四', '1817276212', '上海市普陀区', '长征镇丽和苑1928弄', '878121212@qq.com');

-- --------------------------------------------------------

--
-- 表的结构 `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(20) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL COMMENT '密码',
  `time` int(11) DEFAULT NULL,
  `lasttime` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=45 ;

--
-- 转存表中的数据 `admin`
--

INSERT INTO `admin` (`id`, `name`, `pass`, `time`, `lasttime`, `count`, `status`) VALUES
(39, '张三', 'eyJpdiI6IkhoWVVHRXp3cW9Sd2VwU0VzSjNhQlE9PSIsInZhbHVlIjoicWl4Qm1sUE42cFJNaTlRSWpNc2haQT09IiwibWFjIjoiMzg4M2Y2YmM4MTFlZjhmNjg0MzcxMWZmMzU3OTJlNWViMmQ1YjVjNjFlMWI2MDI0NGYxMGM1MmI1MWM1ZGE4ZSJ9', 1530778189, 1531187044, 2, 0),
(40, 'admin', 'eyJpdiI6Ik40M0tDWTVLTDFGYU9CWXBFMTJDMnc9PSIsInZhbHVlIjoiU1ZUeVFGdzhTdWFsQVg5b0diM1wvZWc9PSIsIm1hYyI6IjIxNjYxNTY0YzE3NjhhOGFmOTM5MzQyMjY0ZDAxMDk5M2E5ZDUyODE2YjQxMjgyYmE3YzlmNWFlYjk3OTY0MzYifQ==', 1530778209, 1531278653, 13, 0),
(41, 'zhangsan', 'eyJpdiI6ImJkV0hsWVBpM2w0eTc1RGVJNGZPcFE9PSIsInZhbHVlIjoiUDd0RWJjUG96WHZ2TWRZWFJOaVF0Zz09IiwibWFjIjoiMDc5MDYzMzMwYThlOGJiZDk1NTYzMTBmYmU1ZGY4YTY4MWZlNDU2ZmZmZTExMDc5YmQ0ZDgwYjZmZGNhOTg0NiJ9', 1530778223, 1531186110, 1, 0),
(42, 'lishi', 'eyJpdiI6IkYwbVNsOVpxcytEekpmdDJtb1hxTWc9PSIsInZhbHVlIjoiUzBmaGplNXNGT2IrSW9vTkRkc3lpdz09IiwibWFjIjoiMjg0YjM1YzI0ODViNTNiOTBiZTVmZTJiMjZiMTA4NDRjOGRkYzQ3ZTU4MDMzNTEwOWZjN2ZiODM4ODRmMGU4YSJ9', 1530779486, 1531186110, 1, 1),
(43, 'wangwu', 'eyJpdiI6IlNXSXNDWG40Z01hUHpzOFhPOGVjVlE9PSIsInZhbHVlIjoiSjBNSFdQMmpoTTg4OVNMd3ZKTklwdz09IiwibWFjIjoiYjI4MmMzMTcyMDZhN2UxNWFkYWVjMWMwMWJhNmQ4ZjQ3Nzc4MWU0YmU1MmE5YWIzMjI2NmJhNWExNTZmNjNmYSJ9', 1530779636, 1531186110, 1, 1),
(44, 'zhaoliu', 'eyJpdiI6ImFWendyQW03R1hhamkzK1ByVUNUVVE9PSIsInZhbHVlIjoiWlwvNGN1OGl5Y1VRV0FLRzRDODFYZHc9PSIsIm1hYyI6IjM4OWJlNTM2NzhmYTZjYzgxNzkxMDU1MTIxN2Y5NjE1ZWFiYzQ0YTM5ODU4NjgxY2RlMDYwYmY5NWRjMTQxNjcifQ==', 1530779647, 1531186110, 1, 0);

-- --------------------------------------------------------

--
-- 表的结构 `ads`
--

CREATE TABLE IF NOT EXISTS `ads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `img` varchar(255) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `href` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- 转存表中的数据 `ads`
--

INSERT INTO `ads` (`id`, `img`, `sort`, `href`, `title`) VALUES
(3, '1531190078214771273.jpg', 12, 'http://www.mobanw.com', '国际皮肤病新技术大会-新技术定点医院亮相'),
(5, '15311900981233456573.jpg', 4, 'http://www.baidu.com', '第二届皮肤病治疗成果展暨患者援助活动'),
(6, '1531190115567970929.jpg', 12, 'http://www.mobanw.com', '【回顾】南宁肤康医院近年大会总结报告'),
(8, '15311903081074567033.jpg', 3, 'http://www.baidu.com', '【回顾】南宁肤康医院近年大会总结报告'),
(9, '15311903231005886145.jpg', 12, 'http://www.mobanw.com', '京、沪三甲专家团联合会诊行动'),
(10, '1531201532443792695.jpg', 4, 'http://www.mobanw.com', '时尚衣服');

-- --------------------------------------------------------

--
-- 表的结构 `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `start` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `statu` tinyint(4) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `comment`
--

INSERT INTO `comment` (`id`, `uid`, `gid`, `text`, `start`, `time`, `statu`, `img`) VALUES
(1, 1, 8, '这是评论商品一内容', 3, 191872643, 1, NULL),
(2, 1, 8, '这是评论商品二内容', 4, 121872643, 1, NULL),
(3, 3, 8, '这是评论商品一内容', 5, 194372643, 2, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `goods`
--

CREATE TABLE IF NOT EXISTS `goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  `text` text,
  `config` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- 转存表中的数据 `goods`
--

INSERT INTO `goods` (`id`, `cid`, `title`, `info`, `img`, `price`, `num`, `text`, `config`) VALUES
(7, 9, 'Romon/罗蒙 西服套装男 时尚修身商务 结婚 新郎服 伴郎服 后中开叉', 'Romon/罗蒙商品简介Romon/罗蒙商品简介Romon/罗蒙商品简介Romon/罗蒙商品简介Romon/罗蒙商品简介Romon/罗蒙商品简介', '15312027671601718705.jpg', 2013, 219, '<p><span style="color: rgb(102, 102, 102); font-family: Arial, &quot;microsoft yahei&quot;; font-weight: 700; background-color: rgb(255, 255, 255);">Romon/罗蒙 西服套装男 时尚修身商务 结婚 新郎服 伴郎服 后中开叉 男士西装男套装 黑色-001 175（西裤尺码请备注）</span></p>', '<ul class="parameter2 p-parameter-list list-paddingleft-2" style="list-style-type: none;"><li><p>商品名称：Romon/罗蒙 西服套装男 时尚修身商务 结婚 新郎服 伴郎服 后中开叉 男士西装男套装 黑色-001 175（西裤尺码请备注）</p></li><li><p>商品编号：28604215781</p></li><li><p>店铺：&nbsp;<a href="https://mall.jd.com/index-804157.html" target="_blank" style="margin: 0px; padding: 0px; color: rgb(94, 105, 173); text-decoration-line: none;">罗蒙齐要专卖店</a></p></li><li><p>商品毛重：1.2kg</p></li><li><p>货号：9001</p></li><li><p>版型：修身型</p></li><li><p>厚度：常规</p></li><li><p>领型：平驳领</p></li><li><p>面料：其他</p></li><li><p>衣门襟：两粒单排扣</p></li><li><p>开叉：后中开衩</p></li><li><p>基础风格：商务绅士</p></li><li><p>主要材质：其他</p></li><li><p>适用人群：青年</p></li></ul><p><br/></p>'),
(8, 10, '阿依莲2018夏季新款欧根纱露肩连衣裙时尚一字领短裙 丁香紫', '阿依莲商品简介阿依莲商品简介阿依莲商品简介阿依莲商品简介阿依莲商品简介阿依莲商品简介阿依莲商品简介', '15312065531950456925.jpg', 2918, 321, '<p><strong style="margin: 0px; padding: 8px 0px 3px; display: inline-block; color: rgb(228, 57, 60); font-family: tahoma, arial, &quot;Microsoft YaHei&quot;, &quot;Hiragino Sans GB&quot;, u5b8bu4f53, sans-serif; font-size: 12px; white-space: normal; background-color: rgb(255, 255, 255);">权利声明：</strong><br/><span style="color: rgb(102, 102, 102); font-family: tahoma, arial, &quot;Microsoft YaHei&quot;, &quot;Hiragino Sans GB&quot;, u5b8bu4f53, sans-serif; font-size: 12px; background-color: rgb(255, 255, 255);">京东上的所有商品信息、客户评价、商品咨询、网友讨论等内容，是京东重要的经营资源，未经许可，禁止非法转载使用。</span></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: tahoma, arial, &quot;Microsoft YaHei&quot;, &quot;Hiragino Sans GB&quot;, u5b8bu4f53, sans-serif; font-size: 12px; white-space: normal; background-color: rgb(255, 255, 255);"><strong style="margin: 0px; padding: 0px;">注：</strong>本站商品信息均来自于合作方，其真实性、准确性和合法性由信息拥有者（合作方）负责。本站不提供任何保证，并不承担任何法律责任。</p><p><br/><strong style="margin: 0px; padding: 8px 0px 3px; display: inline-block; color: rgb(228, 57, 60); font-family: tahoma, arial, &quot;Microsoft YaHei&quot;, &quot;Hiragino Sans GB&quot;, u5b8bu4f53, sans-serif; font-size: 12px; white-space: normal; background-color: rgb(255, 255, 255);">价格说明：</strong><br/></p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: tahoma, arial, &quot;Microsoft YaHei&quot;, &quot;Hiragino Sans GB&quot;, u5b8bu4f53, sans-serif; font-size: 12px; white-space: normal; background-color: rgb(255, 255, 255);"><strong style="margin: 0px; padding: 0px;">京东价：</strong>京东价为商品的销售价，是您最终决定是否购买商品的依据。</p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: tahoma, arial, &quot;Microsoft YaHei&quot;, &quot;Hiragino Sans GB&quot;, u5b8bu4f53, sans-serif; font-size: 12px; white-space: normal; background-color: rgb(255, 255, 255);"><strong style="margin: 0px; padding: 0px;">划线价：</strong>商品展示的划横线价格为参考价，并非原价，该价格可能是品牌专柜标价、商品吊牌价或由品牌供应商提供的正品零售价（如厂商指导价、建议零售价等）或该商品在京东平台上曾经展示过的销售价；由于地区、时间的差异性和市场行情波动，品牌专柜标价、商品吊牌价等可能会与您购物时展示的不一致，该价格仅供您参考。</p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: tahoma, arial, &quot;Microsoft YaHei&quot;, &quot;Hiragino Sans GB&quot;, u5b8bu4f53, sans-serif; font-size: 12px; white-space: normal; background-color: rgb(255, 255, 255);"><strong style="margin: 0px; padding: 0px;">折扣：</strong>如无特殊说明，折扣指销售商在原价、或划线价（如品牌专柜标价、商品吊牌价、厂商指导价、厂商建议零售价）等某一价格基础上计算出的优惠比例或优惠金额；如有疑问，您可在购买前联系销售商进行咨询。</p><p style="margin-top: 0px; margin-bottom: 0px; padding: 0px; color: rgb(102, 102, 102); font-family: tahoma, arial, &quot;Microsoft YaHei&quot;, &quot;Hiragino Sans GB&quot;, u5b8bu4f53, sans-serif; font-size: 12px; white-space: normal; background-color: rgb(255, 255, 255);"><strong style="margin: 0px; padding: 0px;">异常问题：</strong>商品促销信息以商品详情页“促销”栏中的信息为准；商品的具体售价以订单结算页价格为准；如您发现活动商品售价或促销信息有异常，建议购买前先联系销售商咨询。</p><p><br/></p>', '<ul class="p-parameter-list list-paddingleft-2" style="list-style-type: none;"><li><p>品牌：&nbsp;<a href="https://list.jd.com/list.html?cat=1315,1343,9719&ev=exbrand_2944" target="_blank" style="margin: 0px; padding: 0px; color: rgb(94, 105, 173); text-decoration-line: none;">阿依莲（A.YILIAN）</a></p></li><li><p>商品名称：阿依莲2018夏季新款欧根纱露肩连衣裙时尚一字领短裙 丁香紫 M</p></li><li><p>商品编号：24882770595</p></li><li><p>店铺：&nbsp;<a href="https://ayilian.jd.com/" target="_blank" style="margin: 0px; padding: 0px; color: rgb(94, 105, 173); text-decoration-line: none;">阿依莲官方旗舰店</a></p></li><li><p>商品毛重：0.7kg</p></li><li><p>商品产地：中国大陆</p></li><li><p>货号：161382A391</p></li><li><p>腰型：松紧腰</p></li><li><p>风格：OL通勤</p></li><li><p>厚度：适中</p></li><li><p>领型：一字领</p></li><li><p>颜色：白色系，紫色系</p></li><li><p>适用年龄：25-29周岁</p></li><li><p>图案：纯色</p></li><li><p>尺码：S，M，L，XL</p></li><li><p>组合规格：假两件</p></li><li><p>裙型：百褶裙</p></li><li><p>主要材质：聚酯纤维</p></li><li><p>流行元素：露肩</p></li><li><p>袖长：五分袖</p></li><li><p>衣门襟：套头</p></li><li><p>版型：廓型</p></li><li><p>袖型：常规</p></li><li><p>裙长：短裙</p></li><li><p>分类：T恤裙</p></li><li><p>适用人群：胖mm，学生，少女，轻熟女，成熟，亲子</p></li><li><p>上市时间：2016春季</p></li></ul><p><br/></p>'),
(9, 13, '联想笔记本', '联想笔记本联想笔记本联想笔记本联想笔记本联想笔记本联想笔记本联想笔记本', '1531207085238346431.jpg', 7652, 1311, '<p>是是哥哥色</p>', '<p>联想配置</p>'),
(10, 11, '领带', '领带领带领带领带领带领带领带领带领带领带领带领带', '1531278865974279365.jpg', 1012, 311, '<p>领带<span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">商品详情领带<span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">商品详情</span>领带<span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">商品详情</span>领带<span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">商品详情</span>领带<span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">商品详情</span>领带<span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">商品详情</span>领带<span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">商品详情</span>领带<span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">商品详情</span></span></p>', '<p>领带<span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">配置信息</span><span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">配置信息</span><span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">配置信息</span><span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">配置信息</span><span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">配置信息</span><span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">配置信息</span><span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">配置信息</span><span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">配置信息</span><span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">配置信息</span><span style="color: rgb(51, 51, 51); font-family: &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif; font-size: 14px; font-weight: 700; background-color: rgb(255, 255, 255);">配</span></p>');

-- --------------------------------------------------------

--
-- 表的结构 `goodsimg`
--

CREATE TABLE IF NOT EXISTS `goodsimg` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gid` int(11) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- 转存表中的数据 `goodsimg`
--

INSERT INTO `goodsimg` (`id`, `gid`, `img`) VALUES
(1, 4, '15309431681867077487.gif'),
(2, 4, '15309431691252876708.gif'),
(3, 4, '15309431702084700439.gif'),
(4, 4, '15309431712001012430.gif'),
(5, 4, '1530943172831950392.gif'),
(6, 5, '15309434541577521186.jpg'),
(7, 5, '1530943454590459573.png'),
(8, 5, '1530943454849618010.png'),
(9, 5, '15309434541586939218.png'),
(10, 5, '1530943455755899287.png'),
(11, 6, '15309497351891748272.png'),
(12, 6, '15309497351385072859.jpg'),
(13, 6, '15309497351590731628.jpg'),
(14, 6, '1530949735454739995.jpg'),
(15, 7, '15312028511141673956.jpg'),
(16, 7, '15312028611438387450.jpg'),
(17, 7, '1531202861550643169.jpg'),
(18, 7, '1531202861963865567.jpg'),
(19, 8, '1531206559479832290.jpg'),
(20, 8, '1531206559424411661.jpg'),
(21, 8, '15312065591465061124.jpg'),
(22, 9, '15312070892139000099.jpg'),
(23, 9, '1531207107130044824.jpg'),
(24, 9, '15312071071416737906.jpg'),
(25, 9, '15312071071909693288.jpg'),
(26, 10, '15312788721404249914.jpg'),
(27, 10, '15312788722083494126.jpg'),
(28, 10, '153127887232913467.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `money` tinyint(4) DEFAULT NULL,
  `sid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `orders`
--

INSERT INTO `orders` (`id`, `code`, `uid`, `gid`, `price`, `num`, `aid`, `time`, `money`, `sid`) VALUES
(1, '00001', 1, 4, 200, 2, 1, 192191872, 0, 6),
(2, '1100', 3, 5, 400, 1, 2, 2652373, 1, 2),
(3, '1100', 3, 6, 100, 3, 2, 982762423, 1, 3);

-- --------------------------------------------------------

--
-- 表的结构 `orderstatu`
--

CREATE TABLE IF NOT EXISTS `orderstatu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `orderstatu`
--

INSERT INTO `orderstatu` (`id`, `name`) VALUES
(1, '未付款'),
(2, '已发货'),
(3, '在途中'),
(4, '配送中s'),
(5, '签收'),
(6, '已完成');

-- --------------------------------------------------------

--
-- 表的结构 `slider`
--

CREATE TABLE IF NOT EXISTS `slider` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `img` varchar(255) DEFAULT NULL,
  `order` tinyint(4) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `href` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `slider`
--

INSERT INTO `slider` (`id`, `img`, `order`, `title`, `href`) VALUES
(3, '15311895251956630477.jpg', 3, '企业法律顾问+律师上门', 'http://www.mobanw.com'),
(4, '1531189543857968448.jpg', 10, '京、沪三甲专家团联合会诊行动', 'http://www.baidu.com'),
(5, '1531189563854101163.jpg', 3, '国际皮肤病新技术大会-新技术定点医院亮相', 'http://www.mobanw.com');

-- --------------------------------------------------------

--
-- 表的结构 `types`
--

CREATE TABLE IF NOT EXISTS `types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `is_lou` tinyint(4) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `keywords` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- 转存表中的数据 `types`
--

INSERT INTO `types` (`id`, `name`, `pid`, `path`, `sort`, `is_lou`, `title`, `keywords`, `description`) VALUES
(1, '衣服', 0, '0,', 2, 1, '衣服', '衣服', '衣服'),
(2, '数码', 0, '0,', 1, 1, '数码', '数码', '数码'),
(5, '男装', 1, '0,1,', 11, 1, '男装', '男装男装', '男装男装男装男装'),
(6, '女装', 1, '0,1,', 13, 1, '女装', '女装女装', '女装女装女装女装女装'),
(9, '西服', 5, '0,1,5,', 14, 0, '西服', '西服西服', '西服西服西服西服西服'),
(10, '裙子', 6, '0,1,6,', 17, 1, '裙子裙子', '裙子裙子裙子', '裙子裙子裙子裙子裙子'),
(11, '领带', 5, '0,1,5,', 16, 0, '领带', '领带领带', '领带领带领带'),
(12, '电脑', 2, '0,2,', 4, 0, '电脑电脑', '电脑电脑电脑电脑', '电脑电脑电脑'),
(13, '联想笔记本', 12, '0,2,12,', 23, 1, '联想笔记本', '联想笔记本联想笔记本', '联想笔记本联想笔记本联想笔记本'),
(14, '苹果笔记本', 12, '0,2,12,', 12, 0, '苹果笔记本', '苹果笔记本', '苹果笔记本'),
(15, '华硕电脑', 12, '0,2,12,', 6, 0, '华硕电脑', '华硕电脑', '华硕电脑'),
(16, '食品', 0, '0,', 7, 0, '食品食品', '食品食品食品食品', '食品食品'),
(17, '进口牛奶', 16, '0,16,', 4, 0, '进口牛奶进口牛奶进口牛奶', '进口牛奶进口牛奶进口牛奶', '进口牛奶进口牛奶进口牛奶进口牛奶'),
(18, '德运牛奶', 17, '0,16,17,', 4, 0, '德运牛奶德运牛奶德运牛奶', '德运牛奶德运牛奶德运牛奶德运牛奶', '德运牛奶德运牛奶德运牛奶德运牛奶');

-- --------------------------------------------------------

--
-- 表的结构 `typesads`
--

CREATE TABLE IF NOT EXISTS `typesads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(11) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `typesads`
--

INSERT INTO `typesads` (`id`, `cid`, `img`, `type`, `title`) VALUES
(3, 1, '153120159973811379.jpg', 0, '时尚衣服'),
(5, 2, '15312019491838938559.jpg', 0, '数码产品'),
(6, 2, '1531202000183700422.jpg', 0, '数码产品2'),
(7, 1, '1531204841754699856.jpg', 1, '衣服广告'),
(8, 2, '1531204881787888218.jpg', 1, '数码广告');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `pass` varchar(255) DEFAULT NULL,
  `tel` varchar(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  `token` varchar(50) DEFAULT NULL,
  `aid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `pass`, `tel`, `status`, `time`, `token`, `aid`) VALUES
(1, 'user1', '3428654200@qq.com', 'eyJpdiI6IkRralhNaGtiOFVBdGJReEZBRlhLa0E9PSIsInZhbHVlIjoiK2tjNlFrRzdwM3lhd1lPZ3ViOHRjUT09IiwibWFjIjoiMDQ5ZjdiYjQxNjJlZWFhOGUyNDZjMTQ5MjgwOTgzNzU0YzA2YWJkNzNlMDJhYTc0MjAwYjUwMGRjZWRlYjg2YSJ9', '13122457845', 0, 131224578, 'VOS0gkrCNqJU1afEWI3fPNkCqm4SgLYxytSHj2fagKsS9gvkQk', 0),
(2, 'user2', '1158644857@qq.com', 'eyJpdiI6IkRralhNaGtiOFVBdGJReEZBRlhLa0E9PSIsInZhbHVlIjoiK2tjNlFrRzdwM3lhd1lPZ3ViOHRjUT09IiwibWFjIjoiMDQ5ZjdiYjQxNjJlZWFhOGUyNDZjMTQ5MjgwOTgzNzU0YzA2YWJkNzNlMDJhYTc0MjAwYjUwMGRjZWRlYjg2YSJ9', '18544587521', 1, 185445875, 'VOS0gkrCNqJU1afEWI3fPNkCqm4SgLYxytSHj2fagKsS9gvkQk', 1),
(3, 'user3', '136557852@qq.com', 'eyJpdiI6IkRralhNaGtiOFVBdGJReEZBRlhLa0E9PSIsInZhbHVlIjoiK2tjNlFrRzdwM3lhd1lPZ3ViOHRjUT09IiwibWFjIjoiMDQ5ZjdiYjQxNjJlZWFhOGUyNDZjMTQ5MjgwOTgzNzU0YzA2YWJkNzNlMDJhYTc0MjAwYjUwMGRjZWRlYjg2YSJ9', '18544587521', 2, 135445875, 'VOS0gkrCNqJU1afEWI3fPNkCqm4SgLYxytSHj2fagKsS9gvkQk', 2),
(23, 'donglianyou', '1158624818@qq.com', 'eyJpdiI6ImZWV2JaSVRPdFwvK2RyU3E1Z3I2anlRPT0iLCJ2YWx1ZSI6ImtQMzV0VjFhU3ZiZ0ZtaXU1SUwzWEE9PSIsIm1hYyI6IjNkMjcyMjg3MDVlMmZmMDczMmE0MjlkMGU2OWRkYzdjNWRkMTY4MjE5OTYxMjg4NGU4YWJiYzEwMGU1NDBlZDAifQ==', '13122458789', 1, 1531299620, 'UzoqcsJiCda4yOYT2DJHXBQZERkTUMwIoIQm3ZEj9DvYGabTZl', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `userinfo`
--

CREATE TABLE IF NOT EXISTS `userinfo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `sex` tinyint(4) DEFAULT NULL,
  `birthday` int(11) DEFAULT NULL,
  `addr` varchar(255) DEFAULT NULL,
  `addrInfo` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
